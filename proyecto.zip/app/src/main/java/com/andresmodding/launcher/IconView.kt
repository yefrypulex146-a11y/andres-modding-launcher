package com.andresmodding.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class IconView(context: Context, private val tipo: Tipo) : View(context) {

    enum class Tipo { HOME, PIN, SPOTIFY, CHAT, NOTA, BT, CAR, GRID, GEAR, PHONE, PREV, NEXT, PAUSA }

    private var color = Color.WHITE
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    fun pintar(c: Int) {
        color = c
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height) / 24f
        canvas.save()
        canvas.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        canvas.scale(s, s)
        p.color = color
        p.style = Paint.Style.FILL
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        path.reset()
        path.fillType = Path.FillType.WINDING

        when (tipo) {
            Tipo.HOME -> {
                path.moveTo(12f, 3f)
                path.lineTo(2f, 12f)
                path.lineTo(5f, 12f)
                path.lineTo(5f, 21f)
                path.lineTo(10f, 21f)
                path.lineTo(10f, 15f)
                path.lineTo(14f, 15f)
                path.lineTo(14f, 21f)
                path.lineTo(19f, 21f)
                path.lineTo(19f, 12f)
                path.lineTo(22f, 12f)
                path.close()
                canvas.drawPath(path, p)
            }
            Tipo.PIN -> {
                path.fillType = Path.FillType.EVEN_ODD
                path.addCircle(12f, 9f, 7f, Path.Direction.CW)
                path.addCircle(12f, 9f, 2.8f, Path.Direction.CW)
                canvas.drawPath(path, p)
                path.reset()
                path.fillType = Path.FillType.WINDING
                path.moveTo(6.2f, 13f)
                path.lineTo(12f, 22.5f)
                path.lineTo(17.8f, 13f)
                path.close()
                canvas.drawPath(path, p)
            }
            Tipo.SPOTIFY -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.8f
                canvas.drawCircle(12f, 12f, 10f, p)
                p.strokeWidth = 1.9f
                val radios = floatArrayOf(7.5f, 5.7f, 3.9f)
                for (r in radios) {
                    rect.set(12f - r, 16f - r, 12f + r, 16f + r)
                    canvas.drawArc(rect, 215f, 110f, false, p)
                }
            }
            Tipo.CHAT -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.9f
                canvas.drawCircle(12f, 11.5f, 8.5f, p)
                p.style = Paint.Style.FILL
                path.moveTo(4.2f, 21f)
                path.lineTo(6f, 16f)
                path.lineTo(9.5f, 18.5f)
                path.close()
                canvas.drawPath(path, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2.6f
                rect.set(8.2f, 7.7f, 15.8f, 15.3f)
                canvas.drawArc(rect, 70f, 110f, false, p)
            }
            Tipo.NOTA -> {
                canvas.drawCircle(8f, 18f, 3.4f, p)
                canvas.drawRect(10.6f, 4f, 12.4f, 18f, p)
                path.moveTo(12.4f, 4f)
                path.lineTo(19f, 6.5f)
                path.lineTo(19f, 10.5f)
                path.lineTo(12.4f, 8f)
                path.close()
                canvas.drawPath(path, p)
            }
            Tipo.BT -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f
                path.moveTo(6f, 8f)
                path.lineTo(18f, 16f)
                path.lineTo(12f, 21f)
                path.lineTo(12f, 3f)
                path.lineTo(18f, 8f)
                path.lineTo(6f, 16f)
                canvas.drawPath(path, p)
            }
            Tipo.CAR -> {
                rect.set(2f, 11f, 22f, 18f)
                canvas.drawRoundRect(rect, 2.5f, 2.5f, p)
                path.moveTo(5.5f, 11f)
                path.lineTo(8f, 6f)
                path.lineTo(16f, 6f)
                path.lineTo(18.5f, 11f)
                path.close()
                canvas.drawPath(path, p)
                canvas.drawCircle(7f, 18.5f, 2.4f, p)
                canvas.drawCircle(17f, 18.5f, 2.4f, p)
            }
            Tipo.GRID -> {
                rect.set(3f, 3f, 10f, 10f)
                canvas.drawRoundRect(rect, 1.5f, 1.5f, p)
                rect.set(14f, 3f, 21f, 10f)
                canvas.drawRoundRect(rect, 1.5f, 1.5f, p)
                rect.set(3f, 14f, 10f, 21f)
                canvas.drawRoundRect(rect, 1.5f, 1.5f, p)
                rect.set(14f, 14f, 21f, 21f)
                canvas.drawRoundRect(rect, 1.5f, 1.5f, p)
            }
            Tipo.GEAR -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2.6f
                canvas.drawCircle(12f, 12f, 5f, p)
                p.strokeWidth = 3f
                for (i in 0 until 8) {
                    val a = i * Math.PI / 4.0
                    val c = cos(a).toFloat()
                    val sn = sin(a).toFloat()
                    canvas.drawLine(12f + 7.4f * c, 12f + 7.4f * sn, 12f + 10f * c, 12f + 10f * sn, p)
                }
            }
            Tipo.PHONE -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 4.6f
                rect.set(4f, 4f, 20f, 20f)
                canvas.drawArc(rect, 70f, 110f, false, p)
            }
            Tipo.PREV -> {
                canvas.drawRect(5f, 5f, 7.5f, 19f, p)
                path.moveTo(19f, 5f)
                path.lineTo(19f, 19f)
                path.lineTo(8.5f, 12f)
                path.close()
                canvas.drawPath(path, p)
            }
            Tipo.NEXT -> {
                canvas.drawRect(16.5f, 5f, 19f, 19f, p)
                path.moveTo(5f, 5f)
                path.lineTo(5f, 19f)
                path.lineTo(15.5f, 12f)
                path.close()
                canvas.drawPath(path, p)
            }
            Tipo.PAUSA -> {
                canvas.drawRect(6f, 5f, 10f, 19f, p)
                canvas.drawRect(14f, 5f, 18f, 19f, p)
            }
        }
        canvas.restore()
    }
}
