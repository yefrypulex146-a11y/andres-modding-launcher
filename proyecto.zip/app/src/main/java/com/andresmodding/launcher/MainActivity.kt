package com.andresmodding.launcher

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

private const val MP = ViewGroup.LayoutParams.MATCH_PARENT
private const val WC = ViewGroup.LayoutParams.WRAP_CONTENT
private const val ROJO = "#E50914"

class MainActivity : Activity(), LocationListener {

    companion object {
        private var saludoInicialHecho = false
    }

    private var alto = 720f

    private lateinit var raizView: FrameLayout
    private lateinit var gauge: SpeedGaugeView
    private lateinit var pSat: InfoPanelView
    private lateinit var pAlt: InfoPanelView
    private lateinit var pRumbo: InfoPanelView
    private lateinit var pDist: InfoPanelView
    private lateinit var pMax: InfoPanelView
    private lateinit var imgLuces: ImageView
    private lateinit var btnLuces: TextView
    private lateinit var iconBt: IconView
    private lateinit var txtBienvenida: TextView
    private lateinit var locationManager: LocationManager

    private var lucesOn = false
    private var distanciaM = 0f
    private var velMax = 0
    private var ultima: Location? = null
    private var gnssRegistrado = false

    private var tts: TextToSpeech? = null
    private var ttsListo = false
    private var ultimoSaludo = 0L

    private val gnssCb = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(status: GnssStatus) {
            var usados = 0
            for (i in 0 until status.satelliteCount) {
                if (status.usedInFix(i)) usados++
            }
            pSat.setValor("$usados/${status.satelliteCount}")
        }
    }

    private val receptor = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val accion = intent?.action
            if (accion == Intent.ACTION_SCREEN_ON) {
                if (System.currentTimeMillis() - ultimoSaludo > 5 * 60 * 1000L) {
                    saludar()
                }
            } else if (accion == BluetoothAdapter.ACTION_STATE_CHANGED) {
                actualizarBt()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val m = resources.displayMetrics
        alto = minOf(m.widthPixels, m.heightPixels).toFloat()
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager

        cargarViaje()
        construirUi()
        refrescarViaje()
        crearBienvenida()
        iniciarVoz()

        val filtro = IntentFilter()
        filtro.addAction(Intent.ACTION_SCREEN_ON)
        filtro.addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receptor, filtro, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receptor, filtro)
        }

        ponerLuces(esModoNoche())
        actualizarBt()

        if (!tienePermiso()) {
            requestPermissions(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ), 100
            )
        }
    }

    // ---------- Utilidades de diseño ----------

    private fun px(v: Float): Int = v.toInt().coerceAtLeast(1)

    private fun lpm(w: Int, h: Int, peso: Float, margen: Float): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(w, h, peso)
        val mg = px(margen)
        l.setMargins(mg, mg, mg, mg)
        return l
    }

    private fun texto(t: CharSequence, tam: Float, color: Int): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextColor(color)
        v.setTextSize(TypedValue.COMPLEX_UNIT_PX, alto * tam)
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        v.maxLines = 1
        return v
    }

    private fun colores(partes: List<Pair<String, Int>>): SpannableString {
        val total = partes.joinToString("") { it.first }
        val s = SpannableString(total)
        var i = 0
        for (parte in partes) {
            s.setSpan(
                ForegroundColorSpan(parte.second), i, i + parte.first.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            i += parte.first.length
        }
        return s
    }

    private fun efectoToque(v: View) {
        v.setOnTouchListener { vista, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN ->
                    vista.animate().scaleX(0.94f).scaleY(0.94f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    vista.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
    }

    private fun forma(relleno: Int, borde: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(relleno)
        g.setStroke(2, borde)
        g.cornerRadius = alto * 0.025f
        return g
    }

    private fun fondoBoton(seleccionado: Boolean): Drawable {
        val sl = StateListDrawable()
        sl.addState(
            intArrayOf(android.R.attr.state_pressed),
            forma(Color.parseColor(ROJO), Color.WHITE)
        )
        val relleno = if (seleccionado) Color.parseColor("#C20812") else Color.parseColor("#15151B")
        val borde = if (seleccionado) Color.parseColor("#FF4D55") else Color.parseColor("#34343C")
        sl.addState(intArrayOf(), forma(relleno, borde))
        return sl
    }

    private fun iconoBoton(tipo: IconView.Tipo, accion: () -> Unit): IconView {
        val v = IconView(this, tipo)
        v.setOnClickListener { accion() }
        efectoToque(v)
        return v
    }

    // ---------- Construcción de la pantalla ----------

    private fun construirUi() {
        raizView = FrameLayout(this)
        raizView.setBackgroundColor(Color.BLACK)

        val principal = LinearLayout(this)
        principal.orientation = LinearLayout.VERTICAL
        raizView.addView(principal, FrameLayout.LayoutParams(MP, MP))
        principal.addView(barraSuperior(), LinearLayout.LayoutParams(MP, 0, 0.10f))
        principal.addView(cuerpo(), LinearLayout.LayoutParams(MP, 0, 0.66f))
        principal.addView(barraInferior(), LinearLayout.LayoutParams(MP, 0, 0.14f))

        val linea = View(this)
        linea.setBackgroundColor(Color.parseColor(ROJO))
        raizView.addView(linea, FrameLayout.LayoutParams(MP, px(alto * 0.006f), Gravity.TOP))

        setContentView(raizView)
    }

    private fun barraSuperior(): View {
        val fila = LinearLayout(this)
        fila.orientation = LinearLayout.HORIZONTAL
        fila.gravity = Gravity.CENTER_VERTICAL
        fila.setBackgroundColor(Color.parseColor("#0B0B0E"))
        fila.setPadding(px(alto * 0.025f), px(alto * 0.01f), px(alto * 0.025f), px(alto * 0.005f))

        val tam = px(alto * 0.065f)
        val gear = iconoBoton(IconView.Tipo.GEAR) { abrirIntent(Intent(Settings.ACTION_SETTINGS)) }
        fila.addView(gear, lpm(tam, tam, 0f, alto * 0.006f))
        val tel = iconoBoton(IconView.Tipo.PHONE) { abrirIntent(Intent(Intent.ACTION_DIAL)) }
        fila.addView(tel, lpm(tam, tam, 0f, alto * 0.006f))

        val titulo = texto(
            colores(
                listOf(
                    "KIA  " to Color.WHITE,
                    "SPORTAGE EX  " to Color.parseColor("#DDDDDD"),
                    "2017" to Color.parseColor(ROJO)
                )
            ), 0.05f, Color.WHITE
        )
        titulo.gravity = Gravity.CENTER
        titulo.letterSpacing = 0.08f
        fila.addView(titulo, LinearLayout.LayoutParams(0, MP, 1f))

        iconBt = IconView(this, IconView.Tipo.BT)
        fila.addView(iconBt, lpm(tam, tam, 0f, alto * 0.006f))

        val grupoHora = LinearLayout(this)
        grupoHora.orientation = LinearLayout.VERTICAL
        grupoHora.gravity = Gravity.CENTER_HORIZONTAL

        val reloj = TextClock(this)
        reloj.format12Hour = "hh:mm a"
        reloj.format24Hour = "HH:mm"
        reloj.setTextColor(Color.WHITE)
        reloj.setTextSize(TypedValue.COMPLEX_UNIT_PX, alto * 0.042f)
        reloj.setTypeface(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        grupoHora.addView(reloj)

        val fecha = TextClock(this)
        fecha.format12Hour = "EEE d MMM"
        fecha.format24Hour = "EEE d MMM"
        fecha.setTextColor(Color.parseColor(ROJO))
        fecha.setTextSize(TypedValue.COMPLEX_UNIT_PX, alto * 0.022f)
        fecha.setTypeface(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        grupoHora.addView(fecha)

        fila.addView(grupoHora, LinearLayout.LayoutParams(WC, WC))
        return fila
    }

    private fun cuerpo(): View {
        val fila = LinearLayout(this)
        fila.orientation = LinearLayout.HORIZONTAL
        fila.setPadding(px(alto * 0.01f), px(alto * 0.01f), px(alto * 0.01f), px(alto * 0.01f))
        fila.addView(columnaIzquierda(), LinearLayout.LayoutParams(0, MP, 2.8f))
        fila.addView(columnaCentro(), LinearLayout.LayoutParams(0, MP, 4.8f))
        fila.addView(columnaDerecha(), LinearLayout.LayoutParams(0, MP, 2.6f))
        return fila
    }

    private fun columnaIzquierda(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        gauge = SpeedGaugeView(this)
        col.addView(gauge, lpm(MP, 0, 3.0f, alto * 0.004f))

        val fila = LinearLayout(this)
        fila.orientation = LinearLayout.HORIZONTAL
        pDist = InfoPanelView(this, "VIAJE", "km")
        pMax = InfoPanelView(this, "VEL. MÁX", "km/h")
        pDist.setOnLongClickListener {
            reiniciarViaje()
            true
        }
        fila.addView(pDist, lpm(0, MP, 1f, alto * 0.005f))
        fila.addView(pMax, lpm(0, MP, 1f, alto * 0.005f))
        col.addView(fila, lpm(MP, 0, 1f, 0f))
        return col
    }

    private fun columnaCentro(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val fila = LinearLayout(this)
        fila.orientation = LinearLayout.HORIZONTAL
        pSat = InfoPanelView(this, "SATÉLITES")
        pAlt = InfoPanelView(this, "ALTITUD", "m")
        pRumbo = InfoPanelView(this, "RUMBO")
        fila.addView(pSat, lpm(0, MP, 1f, alto * 0.005f))
        fila.addView(pAlt, lpm(0, MP, 1f, alto * 0.005f))
        fila.addView(pRumbo, lpm(0, MP, 1f, alto * 0.005f))
        col.addView(fila, lpm(MP, 0, 0.8f, 0f))

        col.addView(zonaCoche(), lpm(MP, 0, 3.4f, 0f))
        return col
    }

    private fun zonaCoche(): View {
        val f = FrameLayout(this)
        f.addView(DecorView(this, false), FrameLayout.LayoutParams(MP, MP))

        val kia = ImageView(this)
        kia.scaleType = ImageView.ScaleType.FIT_CENTER
        kia.setImageResource(R.drawable.kia)
        f.addView(kia, FrameLayout.LayoutParams(MP, MP))

        imgLuces = ImageView(this)
        imgLuces.scaleType = ImageView.ScaleType.FIT_CENTER
        imgLuces.setImageResource(R.drawable.kia_luces)
        imgLuces.alpha = 0f
        f.addView(imgLuces, FrameLayout.LayoutParams(MP, MP))

        f.addView(DecorView(this, true), FrameLayout.LayoutParams(MP, MP))

        val marca = texto(
            colores(
                listOf(
                    "ANDRES " to Color.WHITE,
                    "MODDING" to Color.parseColor(ROJO)
                )
            ), 0.055f, Color.WHITE
        )
        marca.letterSpacing = 0.06f
        marca.setShadowLayer(20f, 0f, 0f, Color.parseColor(ROJO))
        val lpMarca = FrameLayout.LayoutParams(WC, WC, Gravity.TOP or Gravity.END)
        lpMarca.setMargins(0, px(alto * 0.01f), px(alto * 0.02f), 0)
        f.addView(marca, lpMarca)

        btnLuces = texto("LUCES: OFF", 0.03f, Color.WHITE)
        btnLuces.background = fondoBoton(false)
        btnLuces.gravity = Gravity.CENTER
        btnLuces.setPadding(px(alto * 0.04f), px(alto * 0.014f), px(alto * 0.04f), px(alto * 0.014f))
        btnLuces.setOnClickListener { ponerLuces(!lucesOn) }
        efectoToque(btnLuces)
        val lpL = FrameLayout.LayoutParams(WC, WC, Gravity.BOTTOM or Gravity.START)
        lpL.setMargins(px(alto * 0.01f), 0, 0, px(alto * 0.01f))
        f.addView(btnLuces, lpL)

        return f
    }

    private fun columnaDerecha(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val mapa = MapTileView(this)
        mapa.setOnClickListener { abrirApp("com.google.android.apps.maps") }
        efectoToque(mapa)
        col.addView(mapa, lpm(MP, 0, 1.5f, alto * 0.005f))

        col.addView(tarjetaMusica(), lpm(MP, 0, 1f, alto * 0.005f))
        return col
    }

    private fun tarjetaMusica(): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(px(alto * 0.015f), px(alto * 0.01f), px(alto * 0.015f), px(alto * 0.01f))
        val fondo = GradientDrawable()
        fondo.setColor(Color.parseColor("#CC0B0B0E"))
        fondo.setStroke(3, Color.parseColor(ROJO))
        fondo.cornerRadius = alto * 0.03f
        card.background = fondo

        val cab = LinearLayout(this)
        cab.orientation = LinearLayout.HORIZONTAL
        cab.gravity = Gravity.CENTER_VERTICAL
        val nota = IconView(this, IconView.Tipo.NOTA)
        nota.pintar(Color.parseColor("#4C8DFF"))
        val tn = px(alto * 0.07f)
        cab.addView(nota, LinearLayout.LayoutParams(tn, tn))
        val textos = LinearLayout(this)
        textos.orientation = LinearLayout.VERTICAL
        textos.addView(texto("Música", 0.032f, Color.WHITE))
        textos.addView(texto("Reproductor", 0.022f, Color.parseColor("#AAAAAA")))
        cab.addView(textos, lpm(0, WC, 1f, alto * 0.005f))
        cab.setOnClickListener { abrirMusica() }
        efectoToque(cab)
        card.addView(cab, LinearLayout.LayoutParams(MP, 0, 1f))

        val ctrl = LinearLayout(this)
        ctrl.orientation = LinearLayout.HORIZONTAL
        ctrl.addView(controlMedia(IconView.Tipo.PREV, KeyEvent.KEYCODE_MEDIA_PREVIOUS), lpm(0, MP, 1f, alto * 0.012f))
        ctrl.addView(controlMedia(IconView.Tipo.PAUSA, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE), lpm(0, MP, 1f, alto * 0.012f))
        ctrl.addView(controlMedia(IconView.Tipo.NEXT, KeyEvent.KEYCODE_MEDIA_NEXT), lpm(0, MP, 1f, alto * 0.012f))
        card.addView(ctrl, LinearLayout.LayoutParams(MP, 0, 1f))
        return card
    }

    private fun controlMedia(tipo: IconView.Tipo, codigo: Int): IconView {
        return iconoBoton(tipo) { teclaMedia(codigo) }
    }

    private fun barraInferior(): View {
        val fila = LinearLayout(this)
        fila.orientation = LinearLayout.HORIZONTAL
        fila.setBackgroundColor(Color.parseColor("#08080A"))
        val pad = px(alto * 0.008f)
        fila.setPadding(pad, pad, pad, pad)

        fun b(t: IconView.Tipo, txt: String, sel: Boolean, accion: () -> Unit) {
            fila.addView(botonInferior(t, txt, sel, accion), lpm(0, MP, 1f, alto * 0.004f))
        }

        b(IconView.Tipo.HOME, "INICIO", true) { }
        b(IconView.Tipo.PIN, "MAPS", false) { abrirApp("com.google.android.apps.maps") }
        b(IconView.Tipo.SPOTIFY, "SPOTIFY", false) { abrirApp("com.spotify.music") }
        b(IconView.Tipo.CHAT, "WHATSAPP", false) { abrirApp("com.whatsapp") }

        val logo = texto("KIA", 0.07f, Color.WHITE)
        logo.gravity = Gravity.CENTER
        logo.letterSpacing = 0.15f
        logo.setShadowLayer(18f, 0f, 0f, Color.parseColor(ROJO))
        fila.addView(logo, lpm(0, MP, 1.2f, alto * 0.004f))

        b(IconView.Tipo.NOTA, "MÚSICA", false) { abrirMusica() }
        b(IconView.Tipo.BT, "BLUETOOTH", false) {
            abrirIntent(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        }
        b(IconView.Tipo.CAR, "AUTO", false) { abrirApp("com.google.android.projection.gearhead") }
        b(IconView.Tipo.GRID, "APPS", false) { mostrarApps() }
        return fila
    }

    private fun botonInferior(
        tipo: IconView.Tipo,
        txt: String,
        sel: Boolean,
        accion: () -> Unit
    ): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.background = fondoBoton(sel)
        val ic = IconView(this, tipo)
        val tam = px(alto * 0.075f)
        col.addView(ic, LinearLayout.LayoutParams(tam, tam))
        val t = texto(txt, 0.028f, Color.WHITE)
        t.gravity = Gravity.CENTER
        col.addView(t, LinearLayout.LayoutParams(WC, WC))
        col.setOnClickListener { accion() }
        efectoToque(col)
        return col
    }

    // ---------- Bienvenida y voz ----------

    private fun crearBienvenida() {
        txtBienvenida = TextView(this)
        txtBienvenida.text = "HOLA ANDRÉS,\nBIENVENIDO"
        txtBienvenida.setTextColor(Color.WHITE)
        txtBienvenida.setTextSize(TypedValue.COMPLEX_UNIT_PX, alto * 0.07f)
        txtBienvenida.gravity = Gravity.CENTER
        txtBienvenida.letterSpacing = 0.1f
        txtBienvenida.setTypeface(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        txtBienvenida.setShadowLayer(24f, 0f, 0f, Color.parseColor(ROJO))
        txtBienvenida.setPadding(px(alto * 0.1f), px(alto * 0.05f), px(alto * 0.1f), px(alto * 0.05f))
        val fondo = GradientDrawable()
        fondo.setColor(Color.parseColor("#E6000000"))
        fondo.setStroke(6, Color.parseColor(ROJO))
        fondo.cornerRadius = alto * 0.03f
        txtBienvenida.background = fondo
        txtBienvenida.alpha = 0f
        txtBienvenida.visibility = View.GONE
        raizView.addView(txtBienvenida, FrameLayout.LayoutParams(WC, WC, Gravity.CENTER))
    }

    private fun iniciarVoz() {
        tts = TextToSpeech(this) { estado ->
            if (estado == TextToSpeech.SUCCESS) {
                var r = tts?.setLanguage(Locale("es", "MX"))
                ttsListo = r != TextToSpeech.LANG_MISSING_DATA &&
                    r != TextToSpeech.LANG_NOT_SUPPORTED
                if (!ttsListo) {
                    r = tts?.setLanguage(Locale("es"))
                    ttsListo = r != TextToSpeech.LANG_MISSING_DATA &&
                        r != TextToSpeech.LANG_NOT_SUPPORTED
                }
            }
            if (!saludoInicialHecho) {
                saludoInicialHecho = true
                saludar()
            }
        }
    }

    private fun saludar() {
        ultimoSaludo = System.currentTimeMillis()
        mostrarBienvenida()
        if (ttsListo) {
            tts?.speak("Hola Andrés, bienvenido", TextToSpeech.QUEUE_FLUSH, null, "saludo")
        }
    }

    private fun mostrarBienvenida() {
        txtBienvenida.animate().cancel()
        txtBienvenida.visibility = View.VISIBLE
        txtBienvenida.alpha = 0f
        txtBienvenida.translationY = 60f
        txtBienvenida.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(700)
            .withEndAction {
                txtBienvenida.postDelayed({
                    txtBienvenida.animate()
                        .alpha(0f)
                        .setDuration(900)
                        .withEndAction { txtBienvenida.visibility = View.GONE }
                        .start()
                }, 3500)
            }
            .start()
    }

    // ---------- Luces ----------

    private fun esModoNoche(): Boolean {
        val modo = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return modo == Configuration.UI_MODE_NIGHT_YES
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        ponerLuces(esModoNoche())
    }

    private fun ponerLuces(encender: Boolean) {
        lucesOn = encender
        btnLuces.text = if (encender) "LUCES: ON" else "LUCES: OFF"
        imgLuces.animate().cancel()
        if (encender) {
            imgLuces.animate().alpha(1f).setDuration(120).withEndAction {
                imgLuces.animate().alpha(0.15f).setDuration(120).withEndAction {
                    imgLuces.animate().alpha(1f).setDuration(120).withEndAction {
                        imgLuces.animate().alpha(0.35f).setDuration(120).withEndAction {
                            imgLuces.animate().alpha(1f).setDuration(700).start()
                        }.start()
                    }.start()
                }.start()
            }.start()
        } else {
            imgLuces.animate().alpha(0f).setDuration(900).start()
        }
    }

    // ---------- Bluetooth ----------

    private fun actualizarBt() {
        var activo = false
        try {
            val bm = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
            val ad = bm.adapter
            activo = ad != null && ad.isEnabled
        } catch (e: Exception) {
        }
        iconBt.pintar(if (activo) Color.parseColor("#2F8BFF") else Color.parseColor("#666666"))
    }

    // ---------- Viaje ----------

    private fun cargarViaje() {
        val sp = getSharedPreferences("viaje", MODE_PRIVATE)
        distanciaM = sp.getFloat("dist", 0f)
        velMax = sp.getInt("max", 0)
    }

    private fun guardarViaje() {
        getSharedPreferences("viaje", MODE_PRIVATE).edit()
            .putFloat("dist", distanciaM)
            .putInt("max", velMax)
            .apply()
    }

    private fun refrescarViaje() {
        pDist.setValor(String.format(Locale.US, "%.1f", distanciaM / 1000f))
        pMax.setValor(velMax.toString())
    }

    private fun reiniciarViaje() {
        distanciaM = 0f
        velMax = 0
        ultima = null
        refrescarViaje()
        guardarViaje()
        Toast.makeText(this, "Viaje reiniciado", Toast.LENGTH_SHORT).show()
    }

    // ---------- GPS ----------

    private fun tienePermiso(): Boolean {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
    }

    override fun onResume() {
        super.onResume()
        iniciarGps()
        actualizarBt()
    }

    override fun onPause() {
        super.onPause()
        detenerGps()
        guardarViaje()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(receptor)
        } catch (e: Exception) {
        }
        tts?.stop()
        tts?.shutdown()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        iniciarGps()
    }

    private fun iniciarGps() {
        if (!tienePermiso()) return
        try {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER, 1000L, 0f, this
            )
            if (!gnssRegistrado) {
                locationManager.registerGnssStatusCallback(mainExecutor, gnssCb)
                gnssRegistrado = true
            }
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo activar el GPS", Toast.LENGTH_SHORT).show()
        }
    }

    private fun detenerGps() {
        try {
            locationManager.removeUpdates(this)
            if (gnssRegistrado) {
                locationManager.unregisterGnssStatusCallback(gnssCb)
                gnssRegistrado = false
            }
        } catch (e: Exception) {
        }
    }

    private fun rumbo(grados: Float): String {
        val n = listOf("N", "NE", "E", "SE", "S", "SO", "O", "NO")
        val i = (((grados + 22.5f) % 360f) / 45f).toInt() % 8
        return n[i]
    }

    override fun onLocationChanged(location: Location) {
        val kmh = if (location.hasSpeed()) (location.speed * 3.6f).toInt() else 0
        gauge.setSpeed(kmh)
        if (kmh > velMax) velMax = kmh
        if (location.hasAltitude()) pAlt.setValor(location.altitude.toInt().toString())
        if (location.hasBearing() && kmh >= 3) pRumbo.setValor(rumbo(location.bearing))

        val previa = ultima
        if (previa != null && location.accuracy < 30f && kmh >= 3) {
            val d = previa.distanceTo(location)
            if (d < 200f) distanciaM += d
        }
        ultima = Location(location)
        refrescarViaje()
    }

    // ---------- Acciones ----------

    private fun abrirApp(paquete: String) {
        val intent = packageManager.getLaunchIntentForPackage(paquete)
        if (intent != null) startActivity(intent)
        else Toast.makeText(this, "App no instalada", Toast.LENGTH_SHORT).show()
    }

    private fun abrirIntent(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "No disponible en esta pantalla", Toast.LENGTH_SHORT).show()
        }
    }

    private fun abrirMusica() {
        abrirIntent(
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)
        )
    }

    private fun teclaMedia(codigo: Int) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, codigo))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, codigo))
    }

    private fun mostrarApps() {
        val consulta = Intent(Intent.ACTION_MAIN)
        consulta.addCategory(Intent.CATEGORY_LAUNCHER)
        val lista = packageManager.queryIntentActivities(consulta, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }

        val dialogo = Dialog(this, android.R.style.Theme_Material_NoActionBar)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#F2000000"))
        val cont = LinearLayout(this)
        cont.orientation = LinearLayout.VERTICAL
        cont.setPadding(px(alto * 0.03f), px(alto * 0.03f), px(alto * 0.03f), px(alto * 0.03f))
        scroll.addView(cont, FrameLayout.LayoutParams(MP, WC))

        val cierre = texto("CERRAR  ✕", 0.04f, Color.parseColor(ROJO))
        cierre.gravity = Gravity.END
        cierre.setOnClickListener { dialogo.dismiss() }
        cont.addView(cierre, LinearLayout.LayoutParams(MP, WC))

        val porFila = 6
        var filaActual: LinearLayout? = null
        lista.forEachIndexed { i, ri ->
            if (i % porFila == 0) {
                val nueva = LinearLayout(this)
                nueva.orientation = LinearLayout.HORIZONTAL
                cont.addView(nueva, LinearLayout.LayoutParams(MP, WC))
                filaActual = nueva
            }
            val celda = LinearLayout(this)
            celda.orientation = LinearLayout.VERTICAL
            celda.gravity = Gravity.CENTER
            celda.setPadding(8, px(alto * 0.02f), 8, px(alto * 0.02f))
            val ic = ImageView(this)
            ic.setImageDrawable(ri.loadIcon(packageManager))
            val ti = px(alto * 0.11f)
            celda.addView(ic, LinearLayout.LayoutParams(ti, ti))
            val tx = texto(ri.loadLabel(packageManager), 0.026f, Color.WHITE)
            tx.gravity = Gravity.CENTER
            celda.addView(tx, LinearLayout.LayoutParams(WC, WC))
            val pq = ri.activityInfo.packageName
            celda.setOnClickListener {
                dialogo.dismiss()
                abrirApp(pq)
            }
            filaActual?.addView(celda, LinearLayout.LayoutParams(0, WC, 1f))
        }
        val resto = (porFila - lista.size % porFila) % porFila
        for (k in 0 until resto) {
            filaActual?.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        }

        dialogo.setContentView(scroll)
        dialogo.show()
        dialogo.window?.setLayout(MP, MP)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.insetsController?.hide(WindowInsets.Type.systemBars())
        }
    }
}
