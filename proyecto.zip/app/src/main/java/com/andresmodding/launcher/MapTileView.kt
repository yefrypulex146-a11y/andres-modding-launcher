package com.andresmodding.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

class MapTileView(context: Context) : View(context) {

    private val path = Path()
    private val clip = Path()
    private val rect = RectF()

    private val calle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1B2431")
        style = Paint.Style.STROKE
    }
    private val rutaBrillo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#553B82F6")
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val ruta = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#4C8DFF")
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val flecha = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#4C8DFF")
        style = Paint.Style.FILL
    }
    private val borde = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E50914")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val barra = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E61A1F28")
        style = Paint.Style.FILL
    }
    private val texto = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h * 0.07f

        canvas.save()
        clip.reset()
        rect.set(0f, 0f, w, h)
        clip.addRoundRect(rect, r, r, Path.Direction.CW)
        canvas.clipPath(clip)
        canvas.drawColor(Color.parseColor("#0A0F16"))

        calle.strokeWidth = h * 0.012f
        for (i in 1..6) {
            val x = w * i / 7f + (if (i % 2 == 0) w * 0.02f else -w * 0.015f)
            canvas.drawLine(x, 0f, x + w * 0.05f, h, calle)
        }
        for (j in 1..4) {
            val y = h * j / 5f
            canvas.drawLine(0f, y, w, y + h * 0.04f, calle)
        }

        path.reset()
        path.moveTo(w * 0.62f, h * 0.84f)
        path.lineTo(w * 0.62f, h * 0.58f)
        path.lineTo(w * 0.38f, h * 0.48f)
        path.lineTo(w * 0.38f, h * 0.20f)
        rutaBrillo.strokeWidth = h * 0.07f
        ruta.strokeWidth = h * 0.032f
        canvas.drawPath(path, rutaBrillo)
        canvas.drawPath(path, ruta)

        val ax = w * 0.62f
        val ay = h * 0.80f
        val t = h * 0.09f
        path.reset()
        path.moveTo(ax, ay - t)
        path.lineTo(ax + t * 0.8f, ay + t * 0.7f)
        path.lineTo(ax, ay + t * 0.3f)
        path.lineTo(ax - t * 0.8f, ay + t * 0.7f)
        path.close()
        canvas.drawPath(path, flecha)

        rect.set(w * 0.06f, h * 0.06f, w * 0.94f, h * 0.24f)
        canvas.drawRoundRect(rect, h * 0.09f, h * 0.09f, barra)
        texto.textSize = h * 0.09f
        texto.color = Color.parseColor("#C8C8C8")
        canvas.drawText("Buscar destino", w * 0.12f, h * 0.175f, texto)

        texto.color = Color.WHITE
        texto.textSize = h * 0.095f
        canvas.drawText("NAVEGACIÓN", w * 0.06f, h * 0.95f, texto)
        canvas.restore()

        rect.set(2f, 2f, w - 2f, h - 2f)
        canvas.drawRoundRect(rect, r, r, borde)
    }
}
