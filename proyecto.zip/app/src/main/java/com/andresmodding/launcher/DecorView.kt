package com.andresmodding.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

class DecorView(context: Context, private val frente: Boolean) : View(context) {

    private val aspecto = 1376f / 768f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    private fun franja(canvas: Canvas, x1: Float, x2: Float, h: Float, dx: Float) {
        path.reset()
        path.moveTo(x1, 0f)
        path.lineTo(x2, 0f)
        path.lineTo(x2 - dx, h)
        path.lineTo(x1 - dx, h)
        path.close()
        canvas.drawPath(path, p)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        var iw = w
        var ih = w / aspecto
        if (ih > h) {
            ih = h
            iw = h * aspecto
        }
        val left = (w - iw) / 2f
        val top = (h - ih) / 2f
        val cx = left + iw * 0.5f
        val cy = top + ih * 0.885f
        val rx = iw * 0.42f
        val ry = ih * 0.075f
        rect.set(cx - rx, cy - ry, cx + rx, cy + ry)

        val rojo = Color.parseColor("#E50914")

        if (frente) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = ih * 0.04f
            p.color = Color.parseColor("#33E50914")
            canvas.drawArc(rect, 5f, 170f, false, p)
            p.strokeWidth = ih * 0.014f
            p.color = rojo
            canvas.drawArc(rect, 5f, 170f, false, p)
        } else {
            p.style = Paint.Style.FILL
            p.color = Color.parseColor("#66E50914")
            franja(canvas, w * 0.74f, w * 0.82f, h * 0.65f, w * 0.20f)
            p.color = Color.parseColor("#33E50914")
            franja(canvas, w * 0.85f, w * 0.89f, h * 0.65f, w * 0.20f)
            p.style = Paint.Style.STROKE
            p.strokeWidth = ih * 0.007f
            p.color = Color.parseColor("#66E50914")
            canvas.drawOval(rect, p)
        }
    }
}
