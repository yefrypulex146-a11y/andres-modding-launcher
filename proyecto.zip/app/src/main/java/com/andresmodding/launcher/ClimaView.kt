package com.andresmodding.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import java.util.Random
import kotlin.math.sin

class ClimaView(context: Context) : View(context) {

    enum class Tipo { NINGUNO, LLUVIA, NIEVE, FRIO, TORMENTA }

    private var tipo = Tipo.NINGUNO
    private val rnd = Random(11)
    private val maximo = 70
    private val ax = FloatArray(maximo)
    private val ay = FloatArray(maximo)
    private val vel = FloatArray(maximo)
    private val tam = FloatArray(maximo)
    private var cuantas = 0
    private var ultimo = 0L
    private var tiempo = 0f
    private var rayo = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val velo = Paint()
    private var escarcha: RadialGradient? = null

    fun setTipo(t: Tipo) {
        if (t == tipo) return
        tipo = t
        cuantas = when (t) {
            Tipo.LLUVIA -> 70
            Tipo.TORMENTA -> 70
            Tipo.NIEVE -> 45
            Tipo.FRIO -> 16
            else -> 0
        }
        for (i in 0 until maximo) {
            ax[i] = rnd.nextFloat()
            ay[i] = rnd.nextFloat()
            vel[i] = 0.5f + rnd.nextFloat()
            tam[i] = 0.5f + rnd.nextFloat()
        }
        ultimo = 0L
        rayo = 0f
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) {
            escarcha = RadialGradient(
                w / 2f, h / 2f, maxOf(w, h) * 0.75f,
                intArrayOf(
                    Color.parseColor("#00000000"),
                    Color.parseColor("#00000000"),
                    Color.parseColor("#553F7BFF")
                ),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
        }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE && tipo != Tipo.NINGUNO) {
            ultimo = 0L
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (tipo == Tipo.NINGUNO) return
        val ahora = System.currentTimeMillis()
        var dt = if (ultimo == 0L) 0.03f else (ahora - ultimo) / 1000f
        if (dt > 0.1f) dt = 0.1f
        ultimo = ahora
        tiempo += dt
        val w = width.toFloat()
        val h = height.toFloat()

        when (tipo) {
            Tipo.LLUVIA, Tipo.TORMENTA -> {
                paint.style = Paint.Style.STROKE
                paint.color = Color.parseColor("#99B9D4FF")
                paint.strokeWidth = h * 0.004f + 1f
                paint.strokeCap = Paint.Cap.ROUND
                for (i in 0 until cuantas) {
                    ay[i] += (0.9f + vel[i]) * dt
                    ax[i] -= 0.12f * dt
                    if (ay[i] > 1.05f) {
                        ay[i] = -0.05f
                        ax[i] = rnd.nextFloat() * 1.2f
                    }
                    if (ax[i] < -0.05f) ax[i] += 1.1f
                    val x = ax[i] * w
                    val y = ay[i] * h
                    val largo = h * 0.05f * tam[i]
                    canvas.drawLine(x, y, x + largo * 0.12f, y - largo, paint)
                }
                if (tipo == Tipo.TORMENTA) {
                    if (rayo <= 0f && rnd.nextFloat() < 0.004f) rayo = 1f
                    if (rayo > 0f) {
                        velo.color = Color.argb((rayo * 110).toInt(), 255, 255, 255)
                        canvas.drawRect(0f, 0f, w, h, velo)
                        rayo -= dt * 3f
                    }
                }
            }
            Tipo.NIEVE -> {
                paint.style = Paint.Style.FILL
                paint.color = Color.parseColor("#DDFFFFFF")
                for (i in 0 until cuantas) {
                    ay[i] += (0.10f + 0.12f * vel[i]) * dt
                    ax[i] += sin(tiempo * 1.3f + i) * 0.02f * dt
                    if (ay[i] > 1.05f) {
                        ay[i] = -0.05f
                        ax[i] = rnd.nextFloat()
                    }
                    canvas.drawCircle(ax[i] * w, ay[i] * h, h * 0.008f * (0.6f + tam[i]), paint)
                }
            }
            Tipo.FRIO -> {
                val g = escarcha
                if (g != null) {
                    velo.shader = g
                    canvas.drawRect(0f, 0f, w, h, velo)
                    velo.shader = null
                }
                paint.style = Paint.Style.FILL
                paint.color = Color.parseColor("#AAD6E8FF")
                for (i in 0 until cuantas) {
                    ay[i] -= 0.03f * vel[i] * dt
                    if (ay[i] < -0.05f) {
                        ay[i] = 1.05f
                        ax[i] = rnd.nextFloat()
                    }
                    val r = h * 0.005f * (0.6f + tam[i]) * (0.7f + 0.3f * sin(tiempo * 2f + i))
                    canvas.drawCircle(ax[i] * w, ay[i] * h, r, paint)
                }
            }
            else -> {
            }
        }
        postInvalidateDelayed(40)
    }
}
