package com.andresmodding.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class SpeedGaugeView(context: Context) : View(context) {

    private val maxSpeed = 240f
    private var shown = 0f
    private var objetivo = -1
    private var animator: ValueAnimator? = null
    private var fondo: Bitmap? = null

    private val rect = RectF()
    private var gSize = 0f
    private var gCx = 0f
    private var gCy = 0f
    private var gStroke = 0f
    private var gR = 0f

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#2B2B2B")
    }
    private val zone = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#7A0A10")
    }
    private val progress = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val needle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#BBBBBB")
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
    }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
    }
    private val unit = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E50914")
        textAlign = Paint.Align.CENTER
        letterSpacing = 0.2f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
    }

    fun setSpeed(kmh: Int) {
        if (kmh == objetivo) return
        objetivo = kmh
        animator?.cancel()
        animator = ValueAnimator.ofFloat(shown, kmh.toFloat()).apply {
            duration = 300
            addUpdateListener {
                shown = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        fondo?.recycle()
        fondo = null
        if (w <= 0 || h <= 0) return
        val wf = w.toFloat()
        val hf = h.toFloat()
        gSize = min(wf, hf)
        gCx = wf / 2f
        gCy = hf / 2f
        gStroke = gSize * 0.07f
        gR = gSize / 2f - gStroke * 1.2f
        rect.set(gCx - gR, gCy - gR, gCx + gR, gCy + gR)
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        dibujarFondo(Canvas(b))
        fondo = b
    }

    private fun dibujarFondo(canvas: Canvas) {
        track.strokeWidth = gStroke
        zone.strokeWidth = gStroke
        canvas.drawArc(rect, 135f, 270f, false, track)
        val redStart = 135f + 270f * (200f / maxSpeed)
        canvas.drawArc(rect, redStart, 405f - redStart, false, zone)

        label.textSize = gSize * 0.05f
        var v = 0
        while (v <= 240) {
            val ang = Math.toRadians(135.0 + 270.0 * v / 240.0)
            val c = cos(ang).toFloat()
            val s = sin(ang).toFloat()
            val major = v % 40 == 0
            val r1 = gR - gStroke * 0.8f
            val r2 = r1 - gStroke * (if (major) 0.7f else 0.4f)
            tick.strokeWidth = if (major) gSize * 0.007f else gSize * 0.004f
            tick.color = if (v >= 200) Color.parseColor("#E50914") else Color.WHITE
            canvas.drawLine(gCx + r1 * c, gCy + r1 * s, gCx + r2 * c, gCy + r2 * s, tick)
            if (major) {
                val r3 = r2 - gSize * 0.05f
                canvas.drawText(
                    v.toString(),
                    gCx + r3 * c,
                    gCy + r3 * s + label.textSize * 0.35f,
                    label
                )
            }
            v += 20
        }
    }

    override fun onDraw(canvas: Canvas) {
        val b = fondo ?: return
        canvas.drawBitmap(b, 0f, 0f, null)

        val frac = (shown / maxSpeed).coerceIn(0f, 1f)
        val sweep = 270f * frac
        if (sweep > 1f) {
            progress.strokeWidth = gStroke * 1.7f
            progress.color = Color.parseColor("#44E50914")
            canvas.drawArc(rect, 135f, sweep, false, progress)
            progress.strokeWidth = gStroke
            progress.color = Color.parseColor("#E50914")
            canvas.drawArc(rect, 135f, sweep, false, progress)
        }

        val aguja = Math.toRadians(135.0 + 270.0 * frac)
        val ac = cos(aguja).toFloat()
        val asn = sin(aguja).toFloat()
        val x1 = gCx + gR * 0.62f * ac
        val y1 = gCy + gR * 0.62f * asn
        val x2 = gCx + gR * 0.84f * ac
        val y2 = gCy + gR * 0.84f * asn
        needle.strokeWidth = gSize * 0.03f
        needle.color = Color.parseColor("#44E50914")
        canvas.drawLine(x1, y1, x2, y2, needle)
        needle.strokeWidth = gSize * 0.013f
        needle.color = Color.parseColor("#E50914")
        canvas.drawLine(x1, y1, x2, y2, needle)

        big.textSize = gSize * 0.24f
        unit.textSize = gSize * 0.065f
        canvas.drawText(shown.toInt().toString(), gCx, gCy + gSize * 0.07f, big)
        canvas.drawText("KM/H", gCx, gCy + gSize * 0.17f, unit)
    }
}
