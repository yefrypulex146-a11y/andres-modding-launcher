package com.andresmodding.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class SpeedGaugeView(context: Context) : View(context) {

    private val maxSpeed = 240f
    private var shown = 0f
    private var animator: ValueAnimator? = null
    private val rect = RectF()

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#2B2B2B")
    }
    private val zone = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#7A0A10")
    }
    private val progress = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#E50914")
        strokeCap = Paint.Cap.ROUND
    }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val needle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#E50914")
        strokeCap = Paint.Cap.ROUND
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#BBBBBB")
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
    }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
    }
    private val unit = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E50914")
        textAlign = Paint.Align.CENTER
        letterSpacing = 0.2f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun setSpeed(kmh: Int) {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(shown, kmh.toFloat()).apply {
            duration = 400
            addUpdateListener {
                shown = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val size = min(w, h)
        val cx = w / 2f
        val cy = h / 2f
        val stroke = size * 0.07f
        val r = size / 2f - stroke * 1.2f
        rect.set(cx - r, cy - r, cx + r, cy + r)

        track.strokeWidth = stroke
        zone.strokeWidth = stroke
        progress.strokeWidth = stroke
        progress.setShadowLayer(size * 0.03f, 0f, 0f, Color.parseColor("#E50914"))

        canvas.drawArc(rect, 135f, 270f, false, track)

        val redStart = 135f + 270f * (200f / maxSpeed)
        canvas.drawArc(rect, redStart, 405f - redStart, false, zone)

        val frac = (shown / maxSpeed).coerceIn(0f, 1f)
        val sweep = 270f * frac
        if (sweep > 1f) {
            canvas.drawArc(rect, 135f, sweep, false, progress)
        }

        label.textSize = size * 0.05f
        var v = 0
        while (v <= 240) {
            val ang = Math.toRadians(135.0 + 270.0 * v / 240.0)
            val c = cos(ang).toFloat()
            val s = sin(ang).toFloat()
            val major = v % 40 == 0
            val r1 = r - stroke * 0.8f
            val r2 = r1 - stroke * (if (major) 0.7f else 0.4f)
            tick.strokeWidth = if (major) size * 0.007f else size * 0.004f
            tick.color = if (v >= 200) Color.parseColor("#E50914") else Color.WHITE
            canvas.drawLine(cx + r1 * c, cy + r1 * s, cx + r2 * c, cy + r2 * s, tick)
            if (major) {
                val r3 = r2 - size * 0.05f
                canvas.drawText(
                    v.toString(),
                    cx + r3 * c,
                    cy + r3 * s + label.textSize * 0.35f,
                    label
                )
            }
            v += 20
        }

        val aguja = Math.toRadians(135.0 + 270.0 * frac)
        val ac = cos(aguja).toFloat()
        val asn = sin(aguja).toFloat()
        needle.strokeWidth = size * 0.014f
        needle.setShadowLayer(size * 0.02f, 0f, 0f, Color.parseColor("#E50914"))
        canvas.drawLine(
            cx + r * 0.58f * ac, cy + r * 0.58f * asn,
            cx + r * 0.84f * ac, cy + r * 0.84f * asn,
            needle
        )

        big.textSize = size * 0.24f
        unit.textSize = size * 0.065f
        canvas.drawText(shown.toInt().toString(), cx, cy + size * 0.07f, big)
        canvas.drawText("KM/H", cx, cy + size * 0.17f, unit)
    }
}
