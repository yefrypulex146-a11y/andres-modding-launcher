package com.andresmodding.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.view.View

class InfoPanelView(
    context: Context,
    private val etiqueta: String,
    private val unidad: String = ""
) : View(context) {

    private var valor = "--"
    private val path = Path()

    private val fondo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC0B0B0E")
        style = Paint.Style.FILL
    }
    private val borde = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E50914")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val tEtiqueta = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#B8B8B8")
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
    }
    private val tValor = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
    }

    fun setValor(v: String) {
        if (v != valor) {
            valor = v
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val c = h * 0.28f
        path.reset()
        path.moveTo(c, 2f)
        path.lineTo(w - 2f, 2f)
        path.lineTo(w - 2f, h - c)
        path.lineTo(w - c, h - 2f)
        path.lineTo(2f, h - 2f)
        path.lineTo(2f, c)
        path.close()
        canvas.drawPath(path, fondo)
        canvas.drawPath(path, borde)

        tEtiqueta.textSize = h * 0.2f
        canvas.drawText(etiqueta, w * 0.09f, h * 0.36f, tEtiqueta)

        val texto = if (unidad.isEmpty()) valor else "$valor $unidad"
        var tam = h * 0.40f
        tValor.textSize = tam
        val maximo = w * 0.82f
        val medido = tValor.measureText(texto)
        if (medido > maximo) {
            tam = tam * maximo / medido
            tValor.textSize = tam
        }
        canvas.drawText(texto, w * 0.09f, h * 0.84f, tValor)
    }
}
